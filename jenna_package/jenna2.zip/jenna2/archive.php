<?php
/*
 * The Template for displaying all posts
 * 
 */
$danver_redux_demo = get_option('redux_demo');
get_header(); ?>

<?php if(isset($danver_redux_demo['blog_banner']['url']) && $danver_redux_demo['blog_banner']['url'] != ''){?>
<section class="page__title-area pt-145 pb-150 p-relative page__title-overlay" data-background="<?php echo esc_url($danver_redux_demo['blog_banner']['url']); ?>">
    <?php }else{?>
<section class="page__title-area pt-145 pb-150 p-relative page__title-overlay" data-background="<?php echo get_template_directory_uri();?>/assets/img/page-title/page-title-1.jpg">
    <?php } ?>
   <div class="container">
      <div class="row">
         <div class="col-xxl-12">
            <div class="page__title-wrapper">
               <h3 class="page__title"><?php
                        if ( is_day() ) :
                            printf( esc_html__( 'Daily Archives: %s', 'danver' ), get_the_date() );
                        elseif ( is_month() ) :
                            printf( esc_html__( 'Monthly Archives: %s', 'danver' ), get_the_date( _x( 'F Y', 'monthly archives date format', 'danver' ) ) );
                        elseif ( is_year() ) :
                            printf( esc_html__( 'Yearly Archives: %s', 'danver' ), get_the_date( _x( 'Y', 'yearly archives date format', 'danver' ) ) );
                        else :
                            echo esc_html__( 'Archives', 'danver' );
                        endif;
                        ?></h3>
            </div>
         </div>
      </div>
   </div>
</section>
<!-- page title area end -->

<!-- blog area start -->
<section class="blog__area pt-130 pb-130">
   <div class="container">
      <div class="row">
         <div class="col-xxl-8 col-xl-8 col-lg-8">
            <div class="postbox__wrapper pr-20">
                <?php 
                while (have_posts()): the_post();
                    $single_video = get_post_meta(get_the_ID(),'_cmb_single_video', true);
                    $single_audio = get_post_meta(get_the_ID(),'_cmb_single_audio', true);
                    ?>
               <article class="postbox__item format-image mb-50 transition-3">
                <?php if ( has_post_format('video') ) { ?>
                    <div class="postbox__thumb postbox__video w-img p-relative">
                       <a href="<?php the_permalink();?>">
                        <img src="<?php echo wp_get_attachment_url(get_post_thumbnail_id());?>" alt="">
                    </a>
                    <a href="<?php echo esc_url($single_video);?>" class="play-btn pulse-btn popup-video"><i class="fas fa-play"></i></a>
                </div>
                <?php } elseif ( has_post_format('gallery') ) { ?>
                    <div class="postbox__thumb postbox__slider swiper-container w-img p-relative">
                        <div class="swiper-wrapper">
                            <?php $gallery = get_post_gallery( get_the_ID(), false );

                            if(isset($gallery['ids'])){    
                                $gallery_ids = $gallery['ids'];
                                $img_ids = explode(",",$gallery_ids);
                                $i=0; $j=0;?>
                                <?php   
                                foreach( $img_ids AS $img_id ){ 
                                    $image_src = wp_get_attachment_image_src($img_id,'');
                                    ?>
                                    <div class="postbox__slider-item swiper-slide">
                                   <img src="<?php echo esc_url($image_src[0]); ?>" alt="">
                                </div>
                            <?php } } ?>
                        </div>
                        <div class="postbox-nav">
                            <button class="postbox-slider-button-next"><i class="fal fa-arrow-right"></i></button>
                            <button class="postbox-slider-button-prev"><i class="fal fa-arrow-left"></i></button>
                        </div>
                    </div>
                <?php } elseif ( has_post_format('audio') ) { ?>
                    <div class="postbox__thumb postbox__audio w-img p-relative">
                                 <iframe allow="autoplay" src="<?php echo esc_url($single_audio);?>"></iframe>
                              </div>
                    <?php } elseif ( has_post_thumbnail() ) { ?>
                  <div class="postbox__thumb w-img">
                     <a href="<?php the_permalink();?>">
                        <img src="<?php echo wp_get_attachment_url(get_post_thumbnail_id());?>" alt="">
                     </a>
                  </div>
                  <?php } ?> 
                  <div class="postbox__content">
                     <div class="postbox__meta">
                        <span><i class="far fa-calendar-check"></i> <?php the_time(get_option( 'date_format' ));?> </span>
                        <span><a href="#"><i class="far fa-user"></i> <?php the_author_posts_link(); ?></a></span>
                        <span><a href="#"><i class="fal fa-comments"></i> <?php comments_number( esc_html__('0 Comments', 'danver'), esc_html__('1 Comment', 'danver'), esc_html__('% Comments', 'danver')); ?></a></span>
                     </div>
                     <h3 class="postbox__title">
                        <a href="<?php the_permalink();?>"><?php the_title();?></a>
                     </h3>
                     <div class="postbox__text">
                        <p><?php if(isset($danver_redux_demo['blog_excerpt'])){?>
                                <?php echo esc_attr(danver_excerpt($danver_redux_demo['blog_excerpt'])); ?>
                            <?php }else{?>
                                <?php echo esc_attr(danver_excerpt(40)); 
                            }
                            ?></p>
                     </div>
                     <div class="postbox__read-more">
                        <a href="<?php the_permalink();?>" class="d-btn d-btn-3 d-btn-orange"><?php echo esc_html__( 'read more', 'danver' )?></a>
                     </div>
                  </div>
               </article>
               <?php endwhile; ?>
               
               <div class="basic-pagination">
                  <nav>
                     <?php danver_pagination();?>
                  </nav>
               </div>
            </div>
         </div>
         <div class="col-xxl-4 col-xl-4 col-lg-4">
            <div class="sidebar__wrapper-2">
               <?php get_sidebar();?>
            </div>
         </div>
      </div>
   </div>
</section>
            <!-- blog area end -->

<?php
get_footer();
?>