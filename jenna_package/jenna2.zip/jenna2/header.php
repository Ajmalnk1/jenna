<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<?php $danver_redux_demo = get_option('redux_demo'); ?>
<head>
    <!-- Meta Tags -->
    <meta charset="<?php bloginfo( 'charset' ); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <?php if ( ! function_exists( 'has_site_icon' ) || ! has_site_icon() ) {?>
        <?php if(isset($danver_redux_demo['favicon']['url'])){?>
            <link rel="shortcut icon" href="<?php echo esc_url($danver_redux_demo['favicon']['url']); ?>">
        <?php } ?>
    <?php } ?>
    <?php wp_head(); ?> 
</head>

<body <?php body_class(); ?>>
<div id="loading">
         <div id="loading-center">
            <div id="loading-center-absolute">
               <div class="object" id="object_one"></div>
               <div class="object" id="object_two" ></div>
               <div class="object" id="object_three"></div>
               <div class="object" id="object_four"></div>
               <div class="object" id="object_five"></div>
            </div>
         </div>
      </div>
      <!-- pre loader area end -->

      <!-- back to top start -->
      <div class="progress-wrap">
         <svg class="progress-circle svg-content" width="100%" height="100%" viewBox="-1 -1 102 102">
            <path d="M50,1 a49,49 0 0,1 0,98 a49,49 0 0,1 0,-98" />
         </svg>
      </div>
      <!-- back to top end -->
      
      <!-- header area start -->
      <header>
         <div id="header-sticky" class="header__area header__sticky header__sticky-2">
            <div class="header__bottom-5">
               <div class="container">
                  <div class="row align-items-center">
                     <div class="col-xxl-3 col-xl-3 col-lg-3 col-md-6 col-sm-6 col-5">
                        <?php if(isset($danver_redux_demo['logo']['url']) && $danver_redux_demo['logo']['url'] != ''){?>
                           <div class="logo">
                              <a href="<?php echo esc_url(home_url('/')); ?>">
                                 <img src="<?php echo htmlspecialchars_decode(esc_attr($danver_redux_demo['logo']['url']));?>" alt="">
                              </a>
                           </div>
                        <?php }else{?>
                           <div class="logo">
                              <a href="<?php echo esc_url(home_url('/')); ?>">
                                 <img src="<?php echo get_template_directory_uri();?>/assets/img/logo/logo-black.png" alt="">
                              </a>
                           </div>
                        <?php } ?>
                     </div>
                     <div class="col-xxl-9 col-xl-9 col-lg-9 col-md-6 col-sm-6 col-7">
                        <div class="header__bottom-right-5 d-flex justify-content-end align-items-center">
                           <div class="main-menu main-menu-5 main-menu-12 mr-40">
                              <nav id="mobile-menu">
                                 <?php 
                                 wp_nav_menu( 
                                   array( 
                                     'theme_location' => 'primary',
                                     'container' => '',
                                     'menu_class' => '', 
                                     'menu_id' => '',
                                     'menu'            => '',
                                     'container_class' => '',
                                     'container_id'    => '',
                                     'echo'            => true,
                                     'fallback_cb'       => 'wp_bootstrap_navwalker::fallback',
                                     'walker'            => new danver_wp_bootstrap_navwalker(),
                                     'before'          => '',
                                     'after'           => '',
                                     'link_before'     => '',
                                     'link_after'      => '',
                                     'items_wrap'      => '<ul class=" %2$s">%3$s</ul>',
                                     'depth'           => 0,        
                                  )
                               ); ?>
                              </nav>
                           </div>
                           <div class="header__action header__action-5 header__action-12">
                              <ul>
                                 <li>
                                    <a href="javascript:void(0)" class="search-toggle">
                                       <i class="flaticon-search"></i>
                                    </a>
                                 </li>
                                 <li>
                                    <a href="javascript:void(0)" class="offcanvas-toggle-btn">
                                       <i class="flaticon-menu"></i>
                                    </a>
                                 </li>
                              </ul>
                           </div>
                           <div class="header__btn-5 header__btn-12 ml-10">
                              <?php if($danver_redux_demo['header_button_1'] != ''){?>
                              <a href="<?php echo esc_url($danver_redux_demo['header_link_1']); ?>" class="btn-2 mr-5 d-none d-xxl-inline-block"><?php echo htmlspecialchars_decode(esc_attr($danver_redux_demo['header_button_1']));?></a>
                              <?php } ?>
                              <?php if($danver_redux_demo['header_button_2'] != ''){?>
                              <a href="<?php echo esc_url($danver_redux_demo['header_link_2']); ?>" class="d-none d-xl-inline-block"><?php echo htmlspecialchars_decode(esc_attr($danver_redux_demo['header_button_2']));?></a>
                              <?php } ?>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </header>
      <!-- header area end -->

      <!-- offcanvas area start -->
      <div class="offcanvas__area">
         <div class="offcanvas__wrapper">
            <div class="offcanvas__close">
               <button class="offcanvas__close-btn" id="offcanvas__close-btn">
                  <i class="fal fa-times"></i>
               </button>
            </div>
            <div class="offcanvas__content">
               <?php if(isset($danver_redux_demo['offcanvas_logo']['url']) && $danver_redux_demo['offcanvas_logo']['url'] != ''){?>
               <div class="offcanvas__logo mb-40">
                  <a href="<?php echo esc_url(home_url('/')); ?>">
                  <img src="<?php echo esc_url($danver_redux_demo['offcanvas_logo']['url']); ?>" alt="logo">
                  </a>
               </div>
               <?php }else{?>
               <div class="offcanvas__logo mb-40">
                  <a href="<?php echo esc_url(home_url('/')); ?>">
                  <img src="<?php echo get_template_directory_uri();?>/assets/img/logo/logo-black.png" alt="logo">
                  </a>
               </div>
               <?php } ?>
               <div class="offcanvas__search mb-25">
                  <form action="<?php echo esc_url(home_url('/')); ?>">
                     <input type="text" name="s" placeholder="What are you searching for?">
                     <button type="submit" ><i class="far fa-search"></i></button>
                  </form>
               </div>
               <div class="mobile-menu fix"></div>
               <?php if(isset($danver_redux_demo['offcanvas_content']) && $danver_redux_demo['offcanvas_content'] != ''){?>
               <div class="offcanvas__text d-none d-lg-block">
                  <p><?php echo esc_attr($danver_redux_demo['offcanvas_content']); ?></p>
               </div>
               <?php } ?>
               <div class="offcanvas__img d-none d-lg-block mb-20">
                  <div class="row gx-2">
                     <?php if(isset($danver_redux_demo['offcanvas_img_1']['url']) && $danver_redux_demo['offcanvas_img_1']['url'] != ''){?>
                     <div class="col-4">
                        <div class="offcanvas__single-img w-img mb-10">
                           <a class="popup-img" href="<?php echo esc_url($danver_redux_demo['offcanvas_img_1']['url']); ?>">
                              <img src="<?php echo esc_url($danver_redux_demo['offcanvas_img_1']['url']); ?>" alt="">
                           </a>
                        </div>
                     </div>
                     <?php }else{?>
                        <div class="col-4">
                        <div class="offcanvas__single-img w-img mb-10">
                           <a class="popup-img" href="<?php echo get_template_directory_uri();?>/assets/img/offcanvas/offcanvas-1.jpg">
                              <img src="<?php echo get_template_directory_uri();?>/assets/img/offcanvas/offcanvas-1.jpg" alt="">
                           </a>
                        </div>
                     </div>
                     <?php } ?>
                     <?php if(isset($danver_redux_demo['offcanvas_img_2']['url']) && $danver_redux_demo['offcanvas_img_2']['url'] != ''){?>
                     <div class="col-4">
                        <div class="offcanvas__single-img w-img mb-10">
                           <a class="popup-img" href="<?php echo esc_url($danver_redux_demo['offcanvas_img_2']['url']); ?>">
                              <img src="<?php echo esc_url($danver_redux_demo['offcanvas_img_2']['url']); ?>" alt="">
                           </a>
                        </div>
                     </div>
                     <?php }else{?>
                     <div class="col-4">
                        <div class="offcanvas__single-img w-img mb-10">
                           <a class="popup-img" href="<?php echo get_template_directory_uri();?>/assets/img/offcanvas/offcanvas-2.jpg">
                              <img src="<?php echo get_template_directory_uri();?>/assets/img/offcanvas/offcanvas-2.jpg" alt="">
                           </a>
                        </div>
                     </div>
                     <?php } ?>
                     <?php if(isset($danver_redux_demo['offcanvas_img_3']['url']) && $danver_redux_demo['offcanvas_img_3']['url'] != ''){?>
                     <div class="col-4">
                        <div class="offcanvas__single-img w-img mb-10">
                           <a class="popup-img" href="<?php echo esc_url($danver_redux_demo['offcanvas_img_3']['url']); ?>">
                              <img src="<?php echo esc_url($danver_redux_demo['offcanvas_img_3']['url']); ?>" alt="">
                           </a>
                        </div>
                     </div>
                     <?php }else{?>
                     <div class="col-4">
                        <div class="offcanvas__single-img w-img mb-10">
                           <a class="popup-img" href="<?php echo get_template_directory_uri();?>/assets/img/offcanvas/offcanvas-3.jpg">
                              <img src="<?php echo get_template_directory_uri();?>/assets/img/offcanvas/offcanvas-3.jpg" alt="">
                           </a>
                        </div>
                     </div>
                     <?php } ?>
                     <?php if(isset($danver_redux_demo['offcanvas_img_4']['url']) && $danver_redux_demo['offcanvas_img_4']['url'] != ''){?>
                     <div class="col-4">
                        <div class="offcanvas__single-img w-img mb-10">
                           <a class="popup-img" href="<?php echo esc_url($danver_redux_demo['offcanvas_img_4']['url']); ?>">
                              <img src="<?php echo esc_url($danver_redux_demo['offcanvas_img_4']['url']); ?>" alt="">
                           </a>
                        </div>
                     </div>
                     <?php }else{?>
                     <div class="col-4">
                        <div class="offcanvas__single-img w-img mb-10">
                           <a class="popup-img" href="<?php echo get_template_directory_uri();?>/assets/img/offcanvas/offcanvas-4.jpg">
                              <img src="<?php echo get_template_directory_uri();?>/assets/img/offcanvas/offcanvas-4.jpg" alt="">
                           </a>
                        </div>
                     </div>
                     <?php } ?>
                     <?php if(isset($danver_redux_demo['offcanvas_img_5']['url']) && $danver_redux_demo['offcanvas_img_5']['url'] != ''){?>
                     <div class="col-4">
                        <div class="offcanvas__single-img w-img mb-10">
                           <a class="popup-img" href="<?php echo esc_url($danver_redux_demo['offcanvas_img_5']['url']); ?>">
                              <img src="<?php echo esc_url($danver_redux_demo['offcanvas_img_5']['url']); ?>" alt="">
                           </a>
                        </div>
                     </div>
                     <?php }else{?>
                     <div class="col-4">
                        <div class="offcanvas__single-img w-img mb-10">
                           <a class="popup-img" href="<?php echo get_template_directory_uri();?>/assets/img/offcanvas/offcanvas-5.jpg">
                              <img src="<?php echo get_template_directory_uri();?>/assets/img/offcanvas/offcanvas-5.jpg" alt="">
                           </a>
                        </div>
                     </div>
                     <?php } ?>
                     <?php if(isset($danver_redux_demo['offcanvas_img_6']['url']) && $danver_redux_demo['offcanvas_img_6']['url'] != ''){?>
                     <div class="col-4">
                        <div class="offcanvas__single-img w-img mb-10">
                           <a class="popup-img" href="<?php echo esc_url($danver_redux_demo['offcanvas_img_6']['url']); ?>">
                              <img src="<?php echo esc_url($danver_redux_demo['offcanvas_img_6']['url']); ?>" alt="">
                           </a>
                        </div>
                     </div>
                     <?php }else{?>
                     <div class="col-4">
                        <div class="offcanvas__single-img w-img mb-10">
                           <a class="popup-img" href="<?php echo get_template_directory_uri();?>/assets/img/offcanvas/offcanvas-6.jpg">
                              <img src="<?php echo get_template_directory_uri();?>/assets/img/offcanvas/offcanvas-6.jpg" alt="">
                           </a>
                        </div>
                     </div>
                     <?php } ?>
                  </div>
               </div>
               <?php if(isset($danver_redux_demo['offcanvas_iframe']) && $danver_redux_demo['offcanvas_iframe'] != ''){?>
               <div class="offcanvas__map d-none d-lg-block mb-15">
                  <iframe src="<?php echo htmlspecialchars_decode(esc_attr($danver_redux_demo['offcanvas_iframe']));?>"></iframe>
               </div>
               <?php } ?>
               <div class="offcanvas__contact mt-30 mb-20">
                  <?php if ($danver_redux_demo['offcanvas_contact_title'] != ''){?>
                  <h4><?php echo htmlspecialchars_decode(esc_attr($danver_redux_demo['offcanvas_contact_title']));?></h4>
                  <?php } ?>

                  <ul>
                     <li class="d-flex align-items-center">
                        <?php if($danver_redux_demo['offcanvas_contact_icon_1'] != ''){?>
                        <div class="offcanvas__contact-icon mr-15">
                           <i class="<?php echo htmlspecialchars_decode(esc_attr($danver_redux_demo['offcanvas_contact_icon_1']));?>"></i>
                        </div>
                        <?php } ?>
                        <?php if($danver_redux_demo['offcanvas_contact_location'] != ''){?>
                        <div class="offcanvas__contact-text">
                           <a target="_blank" href="<?php echo esc_url($danver_redux_demo['offcanvas_contact_location_iframe']); ?>"><?php echo htmlspecialchars_decode(esc_attr($danver_redux_demo['offcanvas_contact_location']));?></a>
                        </div>
                        <?php } ?>
                     </li>
                     <li class="d-flex align-items-center">
                        <?php if($danver_redux_demo['offcanvas_contact_icon_2'] != ''){?>
                        <div class="offcanvas__contact-icon mr-15">
                           <i class="<?php echo htmlspecialchars_decode(esc_attr($danver_redux_demo['offcanvas_contact_icon_2']));?>"></i>
                        </div>
                        <?php } ?>
                        <?php if($danver_redux_demo['offcanvas_contact_phone_number'] != ''){?>
                        <div class="offcanvas__contact-text">
                           <a href="<?php echo esc_url($danver_redux_demo['offcanvas_contact_phone_link']); ?>"><?php echo htmlspecialchars_decode(esc_attr($danver_redux_demo['offcanvas_contact_phone_number']));?></a>
                        </div>
                        <?php } ?>
                     </li>
                     <li class="d-flex align-items-center">
                        <?php if($danver_redux_demo['offcanvas_contact_icon_3'] != ''){?>
                        <div class="offcanvas__contact-icon mr-15">
                           <i class="<?php echo htmlspecialchars_decode(esc_attr($danver_redux_demo['offcanvas_contact_icon_3']));?>"></i>
                        </div>
                        <?php } ?>
                        <?php if($danver_redux_demo['offcanvas_contact_email'] != ''){?>
                        <div class="offcanvas__contact-text">
                           <a href="<?php echo esc_url($danver_redux_demo['offcanvas_contact_email_link']); ?>"><?php echo htmlspecialchars_decode(esc_attr($danver_redux_demo['offcanvas_contact_email']));?></a>
                        </div>
                        <?php } ?>
                     </li>
                  </ul>
               </div>
               <div class="offcanvas__social">
                  <ul>
                     <?php if($danver_redux_demo['facebook_link'] != ''){?>
                     <li><a href="<?php echo esc_url($danver_redux_demo['facebook_link']); ?>"><i class="fab fa-facebook-f"></i></a></li>
                     <?php } ?>
                     <?php if($danver_redux_demo['twitter_link'] != ''){?>
                     <li><a href="<?php echo esc_url($danver_redux_demo['twitter_link']); ?>"><i class="fab fa-twitter"></i></a></li>
                     <?php } ?>
                     <?php if($danver_redux_demo['youtube_link'] != ''){?>
                     <li><a href="<?php echo esc_url($danver_redux_demo['youtube_link']); ?>"><i class="fab fa-youtube"></i></a></li>
                     <?php } ?>
                     <?php if($danver_redux_demo['linkedin_link'] != ''){?>
                     <li><a href="<?php echo esc_url($danver_redux_demo['linkedin_link']); ?>"><i class="fab fa-linkedin"></i></a></li>
                     <?php } ?>
                  </ul>
               </div>
            </div>
         </div>
      </div>
      <!-- offcanvas area end -->      
      <div class="body-overlay"></div>
      <!-- offcanvas area end -->

      <!-- search overlay start -->
      <section class="search__area d-flex align-items-center">
         <div class="container">
            <div class="row">
               <div class="col-xxl-12">
                  <div class="search__wrapper">
                     <div class="search__close">
                        <button class="search-close-btn"><i class="fal fa-times"></i></button>
                     </div>
                     <form action="<?php echo esc_url(home_url('/')); ?>">
                        <div class="search__input">
                           <input type="text" placeholder="Search here..." name="s">
                           <button type="submit"><i class="far fa-search"></i></button>
                        </div>
                     </form>
                  </div>
               </div>
            </div>
         </div>
      </section>
      <!-- search overlay end -->


      <main>