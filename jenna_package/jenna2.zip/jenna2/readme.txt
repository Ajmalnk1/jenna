/*
    Theme Name: Jenna 2
	Theme URI: http://shtheme.com/demosd/jenna2
	Author: Shtheme
	Author URI: https://themeforest.net/user/shtheme
    Release Date: 31 August 2023
    Requirements: WordPress 5.6 or higher, PHP 5
    Compatibility: WordPress 5.6
    Tags: web app
    Last Update Date: 31 August 2023
*/

/**** Readme ****/

"Please backup your theme pack files at first before you update the theme into the latest version"


2023.08.31 - version 1.0.0
- First release.
