<?php
/**
 * The template for displaying 404 pages (Not Found)
 */
$danver_redux_demo = get_option('redux_demo');
get_header(); ?> 

<?php if(isset($danver_redux_demo['404_banner']['url']) && $danver_redux_demo['404_banner']['url'] != ''){?>
    <section class="page__title-area pt-145 pb-150 p-relative page__title-overlay" data-background="<?php echo esc_url($danver_redux_demo['404_banner']['url']); ?>">
    <?php }else{?>
        <section class="page__title-area pt-145 pb-150 p-relative page__title-overlay" data-background="<?php echo get_template_directory_uri();?>/assets/img/page-title/page-title-1.jpg">
        <?php } ?>
        <div class="container">
          <div class="row">
             <div class="col-xxl-12">
                <div class="page__title-wrapper">
                   <h3 class="page__title"><?php if(isset($danver_redux_demo['404_heading']) && $danver_redux_demo['404_heading'] != ''){?>
                    <?php echo htmlspecialchars_decode(esc_attr($danver_redux_demo['404_heading']));?>
                <?php }else{?>
                    <?php echo esc_html__( '404 Page', 'danver' );
                }
                ?></h3>
                <nav aria-label="breadcrumb">
                  <ol class="breadcrumb">
                      <li class="breadcrumb-item"><a href="<?php echo esc_url(home_url('/')); ?>"><?php echo esc_html__( 'Home', 'danver' )?></a></li>
                      <li class="breadcrumb-item active" aria-current="page"><?php if(isset($danver_redux_demo['404_sub_heading']) && $danver_redux_demo['404_sub_heading'] != ''){?>
                        <?php echo htmlspecialchars_decode(esc_attr($danver_redux_demo['404_sub_heading']));?>
                    <?php }else{?>
                        <?php echo esc_html__( '404 Error', 'danver' );
                    }
                    ?></li>
                </ol>
            </nav>
        </div>
    </div>
</div>
</div>
</section>

    <div class="section-padding error-section">
        <div class="container">
            <div class="row">
                <div class="col-md-6 offset-md-3 text-center"> 
                    <?php if(isset($danver_redux_demo['404_image']['url']) && $danver_redux_demo['404_image']['url'] != ''){?>
                        <img src="<?php echo esc_url($danver_redux_demo['404_image']['url']); ?>" class="mb-30" alt="">
                    <?php }else{?>
                        <img src="<?php echo get_template_directory_uri();?>/assets/img/404-image.png" class="mb-30" alt="">
                    <?php } ?>
                    <div class="section-title"><?php if(isset($danver_redux_demo['404_title']) && $danver_redux_demo['404_title'] != ''){?>
                        <?php echo htmlspecialchars_decode(esc_attr($danver_redux_demo['404_title']));?>
                    <?php }else{?>
                        <?php echo esc_html__( 'Sorry We Cant Find', 'danver' );
                    }?> <span><?php if(isset($danver_redux_demo['404_subtitle']) && $danver_redux_demo['404_subtitle'] != ''){?>
                        <?php echo htmlspecialchars_decode(esc_attr($danver_redux_demo['404_subtitle']));?>
                    <?php }else{?>
                        <?php echo esc_html__( 'That Page!', 'danver' );
                    }?></span></div>
                    <p><?php if(isset($danver_redux_demo['404_desc']) && $danver_redux_demo['404_desc'] != ''){?>
                        <?php echo htmlspecialchars_decode(esc_attr($danver_redux_demo['404_desc']));?>
                    <?php }else{?>
                        <?php echo esc_html__( 'The page you are looking for was moved, removed, renamed or never existed.', 'danver' );
                    }?></p>
                    <a href="<?php echo esc_url(home_url('/')); ?>" class="butn butn-dark mt-30 animated zoomIn"><span><?php if(isset($danver_redux_demo['404_button']) && $danver_redux_demo['404_button'] != ''){?>
                            <?php echo htmlspecialchars_decode(esc_attr($danver_redux_demo['404_button']));?>
                        <?php }else{?>
                            <?php echo esc_html__( 'Back to home', 'danver' );
                        }?></span></a>
                    </div>
                </div>
            </div>
        </div>

        <?php get_footer(); ?>