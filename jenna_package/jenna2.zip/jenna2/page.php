<?php
/**
 * The Template for displaying all single posts
 */
$danver_redux_demo = get_option('redux_demo');
get_header(); ?>

<?php 
while (have_posts()): the_post();
    $single_image = get_post_meta(get_the_ID(),'_cmb_single_image', true);
?>

<div class="blog-home section-padding">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="item animate-box" data-animate-effect="fadeInUp">
                    <?php if (has_post_thumbnail()) { ?> 
                    <div class="post-img mb-30">
                        <div class="img"><img src="<?php echo wp_get_attachment_url($single_image);?>" alt=""></div>
                    </div>
                    <?php } ?>
                    <div class="cont">
                        <div class="info"><?php the_time(get_option( 'date_format'));?> </div>
                        <h3><?php the_title();?></h3>
                        <?php the_content(); ?>
                        <?php wp_link_pages(); ?>
                    </div>
                </div>
            </div> 
        </div>
        <div class="row">
            <div class="col-md-12 animate-box" data-animate-effect="fadeInUp">
                <?php comments_template();?>
            </div>
        </div>
    </div>
</div>
<!-- Call Action Section -->
<div class="call-action section-padding bg-img bg-fixed" data-overlay-dark="1" data-background="<?php echo get_template_directory_uri();?>/assets/images/call.jpg">
    <div class="container">
        <div class="row">
            <div class="col-md-12 mb-5">
                <div class="text-center">
                    <h2>Want to work together!</h2>
                    <h5>I’m available for freelance work.</h5>
                    <div class="btn-3"><a href="<?php echo esc_url(home_url('/')); ?>#contact"><span>Hire Me&nbsp;&nbsp;<small><i class="ti-angle-down"></i></small></span></a></div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php endwhile; ?>
<?php
get_footer();
?>