<?php $danver_redux_demo = get_option('redux_demo'); ?>

</main>

      <!-- footer area start -->
      <footer>
         <div class="footer__area black-bg-2">
            <div class="footer__top footer__top-7 pt-95 mb-35">
               <div class="container">
                  <div class="row">
                     <div class="col-xxl-3 col-xl-3 col-lg-4 col-md-6 col-sm-7">
                        <?php if ( is_active_sidebar( 'footer-7-widget-1' ) ) : ?>
                        <?php dynamic_sidebar( 'footer-7-widget-1' ); ?>
                    <?php endif; ?>
                     </div>
                     <div class="col-xxl-3 col-xl-3 col-lg-4 col-md-6 col-sm-5">
                        <?php if ( is_active_sidebar( 'footer-7-widget-2' ) ) : ?>
                        <?php dynamic_sidebar( 'footer-7-widget-2' ); ?>
                    <?php endif; ?>
                     </div>
                     <div class="col-xxl-3 col-xl-3 col-lg-4 col-md-6 col-sm-6">
                        <?php if ( is_active_sidebar( 'footer-7-widget-3' ) ) : ?>
                        <?php dynamic_sidebar( 'footer-7-widget-3' ); ?>
                    <?php endif; ?>
                     </div>
                     <div class="col-xxl-3 col-xl-3 col-lg-4 col-md-6 col-sm-6">
                        <?php if ( is_active_sidebar( 'footer-7-widget-4' ) ) : ?>
                           <?php dynamic_sidebar( 'footer-7-widget-4' ); ?>
                       <?php endif; ?>
                     </div>
                  </div>
               </div>
            </div>
            <div class="footer__bottom-3 footer__bottom-7">
               <div class="container">
                  <div class="row align-items-center">
                     <div class="col-xxl-12">
                        <div class="footer__copyright footer__copyright-3 footer__copyright-7 text-center">
                           <?php if(isset($danver_redux_demo['footer_7_text']) && $danver_redux_demo['footer_7_text'] != ''){?>
                                 <p class="text-rubik"><?php echo htmlspecialchars_decode(esc_attr($danver_redux_demo['footer_7_text']));?></p>
                              <?php }else{?>
                                 <p class="text-rubik"><?php echo esc_html__( '© Copyrighted & Designed by Theme_Pure', 'danver' )?></p>
                              <?php } ?>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </footer>
<?php wp_footer(); ?>
</body>
</html>