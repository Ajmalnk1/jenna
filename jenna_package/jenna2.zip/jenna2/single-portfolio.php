<?php
/**
 * The Template for displaying all single posts
 */
$danver_redux_demo = get_option('redux_demo');
get_header(); ?>

<?php 
while (have_posts()): the_post();
  ?>

<?php if(isset($danver_redux_demo['blog_banner']['url']) && $danver_redux_demo['blog_banner']['url'] != ''){?>
  <section class="page__title-area pt-145 pb-150 p-relative page__title-overlay" data-background="<?php echo esc_url($danver_redux_demo['blog_banner']['url']); ?>">
<?php }else{?>
  <section class="page__title-area pt-145 pb-150 p-relative page__title-overlay" data-background="<?php echo get_template_directory_uri();?>/assets/img/page-title/page-title-1.jpg">
<?php } ?>
  <div class="container">
    <div class="row">
     <div class="col-xxl-12">
      <div class="page__title-wrapper">
       <h3 class="page__title"><?php the_title();?></h3>
          <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="<?php echo esc_url(home_url('/')); ?>"><?php echo esc_html__( 'Home', 'danver' )?></a></li>
              <li class="breadcrumb-item active" aria-current="page"><?php the_title();?></li>
            </ol>
          </nav>
        </div>
      </div>
    </div>
  </div>
</section>
<!-- page title area end -->

<!-- portfolio area start -->
<section class="portfolio__area pt-120">
 <div class="container">
  <div class="row">
   <div class="col-xxl-8 col-xl-8 col-lg-8">
    <div class="portfolio__details">
    <?php the_content(); ?>
    <?php wp_link_pages(); ?>
  </div>
</div>
<div class="col-xxl-4 col-xl-4 col-lg-4">
  <div class="portfolio__widget">
   <?php get_sidebar('portfolio');?>
 </div>
</div>
</div>
</div>
</section>
<!-- portfolio area end -->
<!-- services details area end -->

<!-- brand area start -->
<section class="brand__area pt-120 pb-120">
 <div class="container">
  <div class="row">
   <div class="col-xxl-12">
    <div class="brand__slider-4 owl-carousel">
     <div class="brand__item-4 text-center">
      <img src="<?php echo get_template_directory_uri();?>/assets/img/brand/4/brand-1.png" alt="">
    </div>
    <div class="brand__item-4 text-center">
      <img src="<?php echo get_template_directory_uri();?>/assets/img/brand/4/brand-2.png" alt="">
    </div>
    <div class="brand__item-4 text-center">
      <img src="<?php echo get_template_directory_uri();?>/assets/img/brand/4/brand-3.png" alt="">
    </div>
    <div class="brand__item-4 text-center">
      <img src="<?php echo get_template_directory_uri();?>/assets/img/brand/4/brand-4.png" alt="">
    </div>
    <div class="brand__item-4 text-center">
      <img src="<?php echo get_template_directory_uri();?>/assets/img/brand/4/brand-5.png" alt="">
    </div>
  </div>
</div>
</div>
</div>
</section>

<?php endwhile; ?>
<?php
get_footer();
?>