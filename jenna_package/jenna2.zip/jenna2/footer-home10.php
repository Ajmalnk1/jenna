<?php $danver_redux_demo = get_option('redux_demo'); ?>

</main>

      <!-- footer area start -->
      <footer>
         <div class="footer__area black-bg-2">
            <div class="footer__top mb-35">
               <div class="container">
                  <div class="row">
                     <div class="col-xxl-3 col-xl-3 col-lg-4 col-md-6 col-sm-7">
                        <?php if ( is_active_sidebar( 'footer-10-widget-1' ) ) : ?>
                        <?php dynamic_sidebar( 'footer-10-widget-1' ); ?>
                    <?php endif; ?>
                     </div>
                     <div class="col-xxl-3 col-xl-3 col-lg-4 col-md-6 col-sm-5">
                        <?php if ( is_active_sidebar( 'footer-10-widget-2' ) ) : ?>
                        <?php dynamic_sidebar( 'footer-10-widget-2' ); ?>
                    <?php endif; ?>
                     </div>
                     <div class="col-xxl-3 col-xl-3 col-lg-4 col-md-6 col-sm-6">
                        <?php if ( is_active_sidebar( 'footer-10-widget-3' ) ) : ?>
                        <?php dynamic_sidebar( 'footer-10-widget-3' ); ?>
                    <?php endif; ?>
                     </div>
                     <div class="col-xxl-3 col-xl-3 col-lg-4 col-md-6 col-sm-6">
                        <?php if ( is_active_sidebar( 'footer-10-widget-4' ) ) : ?>
                        <?php dynamic_sidebar( 'footer-10-widget-4' ); ?>
                    <?php endif; ?>
                     </div>
                  </div>
               </div>
            </div>
            <div class="footer__bottom-4">
               <div class="container">
                  <div class="row align-items-center">
                     <div class="col-xxl-6 col-xl-6 col-md-6">
                        <div class="footer__copyright footer__copyright-9">
                           <?php if(isset($danver_redux_demo['footer_10_text']) && $danver_redux_demo['footer_10_text'] != ''){?>
                              <p><?php echo htmlspecialchars_decode(esc_attr($danver_redux_demo['footer_10_text']));?></p>
                            <?php }else{?>
                           <p><?php echo esc_html__( '© Copyrighted & Designed by Theme_Pure', 'danver' )?></p>
                           <?php } ?>
                        </div>
                     </div>
                     <div class="col-xxl-6 col-xl-6 col-md-6">
                        <div class="footer__bottom-link footer__bottom-link-4 d-flex justify-content-md-end">
                           <ul>
                              <?php if(isset($danver_redux_demo['footer_10_terms']) && $danver_redux_demo['footer_10_terms'] != ''){?>
                              <li><a href="<?php echo esc_url($danver_redux_demo['footer_10_terms_link']); ?>"><?php echo esc_attr($danver_redux_demo['footer_10_terms']); ?></a></li>
                              <?php } ?>
                              <?php if(isset($danver_redux_demo['footer_10_career']) && $danver_redux_demo['footer_10_career'] != ''){?>
                              <li><a href="<?php echo esc_url($danver_redux_demo['footer_10_career_link']); ?>"><?php echo esc_attr($danver_redux_demo['footer_10_career']); ?></a></li>
                              <?php } ?>
                              <?php if(isset($danver_redux_demo['footer_10_development']) && $danver_redux_demo['footer_10_development'] != ''){?>
                              <li><a href="<?php echo esc_url($danver_redux_demo['footer_10_development_link']); ?>"><?php echo esc_attr($danver_redux_demo['footer_10_development']); ?></a></li>
                              <?php } ?>
                           </ul>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </footer>
<?php wp_footer(); ?>
</body>
</html>