<?php $danver_redux_demo = get_option('redux_demo'); ?>

</main>

      <!-- footer area start -->
      <footer>
         <div class="footer__area black-bg">
            <div class="footer__top">
               <div class="container">
                  <div class="row">
                     <div class="col-xxl-4 col-xl-4 col-lg-6 col-md-7 col-sm-7">
                        <?php if ( is_active_sidebar( 'footer-2-widget-1' ) ) : ?>
                        <?php dynamic_sidebar( 'footer-2-widget-1' ); ?>
                    <?php endif; ?>
                     </div>
                     <div class="col-xxl-3 col-xl-3 col-lg-6 col-md-5 col-sm-5">
                        <?php if ( is_active_sidebar( 'footer-2-widget-2' ) ) : ?>
                        <?php dynamic_sidebar( 'footer-2-widget-2' ); ?>
                    <?php endif; ?>
                     </div>
                     <div class="col-xxl-2 col-xl-2 col-lg-6 col-md-6 col-sm-6">
                        <?php if ( is_active_sidebar( 'footer-2-widget-3' ) ) : ?>
                        <?php dynamic_sidebar( 'footer-2-widget-3' ); ?>
                    <?php endif; ?>
                     </div>
                     <div class="col-xxl-3 col-xl-3 col-lg-6 col-md-6 col-sm-6">
                        <?php if ( is_active_sidebar( 'footer-2-widget-4' ) ) : ?>
                        <?php dynamic_sidebar( 'footer-2-widget-4' ); ?>
                    <?php endif; ?>
                     </div>
                  </div>
               </div>
            </div>
            <div class="footer__bottom">
               <div class="container">
                  <div class="footer__bottom-wrapper footer-bottom-bg">
                     <div class="row align-items-center">
                        <div class="col-xxl-4 col-xl-4 col-lg-6 col-md-6">
                           <div class="footer__copyright footer__line footer__copyright-2">
                              <?php if(isset($danver_redux_demo['footer_2_text']) && $danver_redux_demo['footer_2_text'] != ''){?>
                                 <p><?php echo htmlspecialchars_decode(esc_attr($danver_redux_demo['footer_2_text']));?></p>
                              <?php }else{?>
                                 <p><?php echo esc_html__( '© Copyrighted & Designed by Theme_Pure', 'danver' )?></p>
                              <?php } ?>
                           </div>

                        </div>
                        <div class="col-xxl-3 col-xl-3 col-lg-6 col-md-6">
                           <div class="footer__call footer__call-2 d-flex align-items-center pl-15 footer__line footer__line-2">
                              <?php if($danver_redux_demo['footer_2_call_icon'] != ''){?>
                              <div class="footer__call-icon mr-20">
                                 <i class="<?php echo esc_attr($danver_redux_demo['footer_2_call_icon']); ?>"></i>
                              </div>
                              <?php } ?>
                              <div class="footer__call-content">
                                 <?php if($danver_redux_demo['footer_2_call_title'] != ''){?>
                                 <p><?php echo esc_attr($danver_redux_demo['footer_2_call_title']); ?></p>
                                 <?php } ?>
                                 <?php if($danver_redux_demo['footer_2_call_number'] != ''){?>
                                 <h5 class="text-libre"><a href="<?php echo esc_url($danver_redux_demo['footer_2_call_link']); ?>"><?php echo esc_attr($danver_redux_demo['footer_2_call_number']); ?></a></h5>
                                 <?php } ?>
                              </div>
                           </div>
                        </div>
                        <div class="col-xxl-5 col-xl-5 col-md-8">
                           <div class="footer__contact pl-90">
                              <?php if($danver_redux_demo['footer_2_contact_title'] != ''){?>
                              <h3 class="text-libre"><?php echo esc_attr($danver_redux_demo['footer_2_contact_title']); ?></h3>
                              <?php } ?>
                              <ul>
                                 <li>
                                    <?php if($danver_redux_demo['footer_2_contact_content_1'] != ''){?>
                                    <?php echo htmlspecialchars_decode(esc_attr($danver_redux_demo['footer_2_contact_content_1']));?>
                                    <?php } ?>
                                 </li>
                                 <li>
                                    <?php if($danver_redux_demo['footer_2_contact_content_2'] != ''){?>
                                    <?php echo htmlspecialchars_decode(esc_attr($danver_redux_demo['footer_2_contact_content_2']));?>
                                    <?php } ?>
                                 </li>
                              </ul>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </footer>
<?php wp_footer(); ?>
</body>
</html>