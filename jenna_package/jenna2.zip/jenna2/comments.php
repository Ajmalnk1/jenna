<?php
/**
 * The template for displaying Comments.
 *
 * The area of the page that contains comments and the comment form.
 * If the current post is protected by a password and the visitor has not yet
 * entered the password we will return early without loading the comments.
 */
if ( post_password_required() )
    return;
?>

  <?php if ( have_comments() ) : ?>

<div class="post__comment">
  <h3 class="comments-title"><?php comments_number( esc_html__('0 Comments', 'danver'), esc_html__('1 Comment', 'danver'), esc_html__('% Comments', 'danver')); ?></h3>
  <?php wp_list_comments('callback=danver_theme_comment'); ?>
</div>
                               
<?php
        // Are there comments to navigate through?
if ( get_comment_pages_count() > 1 && get_option( 'page_comments' ) ) :
  ?>
<div class="text-center">
  <ul class="pagination">
    <li>
      <?php //Create pagination links for the comments on the current post, with single arrow heads for previous/next
      paginate_comments_links( array(
        'prev_text' => wp_specialchars_decode(esc_html__( '<i class="ti-angle-left"></i>', 'danver' ),ENT_QUOTES), 
        'next_text' => wp_specialchars_decode(esc_html__( '<i class="ti-angle-right"></i>', 'danver' ),ENT_QUOTES)
      ));  ?>
    </li> 
  </ul>
</div>
<?php endif; // Check for comment navigation ?>
<?php endif; ?>
<?php
    if ( is_singular() ) wp_enqueue_script( "comment-reply" );
        $aria_req = ( $req ? " aria-required='true'" : '' );
        $comment_args = array(
                'id_form' => 'commentform',        
                'class_form' => '',                         
                'title_reply'=> esc_html__( 'Leave a comment', 'danver' ),
                'fields' => apply_filters( 'comment_form_default_fields', array(
                    'author' => '<div class="col-xxl-6">
                                  <div class="postbox__comment-input">
                                    <span>'.esc_attr__('Your Name*', 'danver').'</span>
                                    <input type="text" name="author">
                                  </div>
                                </div>',
                    'email' => '<div class="col-xxl-6">
                                    <div class="postbox__comment-input">
                                      <span>'.esc_attr__('Your email*', 'danver').'</span>
                                      <input type="text" name="email">
                                    </div>
                                </div>'
                ) ),
                'comment_field' => '<div class="col-xxl-12">
                                        <div class="postbox__comment-input">
                                          <span>'.esc_attr__('Write A Comment*', 'danver').'</span>
                                          <textarea name="comment" id="message"></textarea>
                                        </div>
                                    </div>',                    
                 'label_submit' => esc_attr__( 'Post a Comment', 'danver' ),
                 'class_submit' => 'd-btn d-btn-3 d-btn-orange',
                 'comment_notes_before' => '',
                 'comment_notes_after' => '',               
        )
    ?>
<?php if ( comments_open() ) : ?>
  <div class="postbox__comment">
      <?php comment_form($comment_args); ?>
  </div>
<?php endif; ?>